import './style.css'

export default function Loader () {
    return (
        <div className="banana"></div>
    )
}
