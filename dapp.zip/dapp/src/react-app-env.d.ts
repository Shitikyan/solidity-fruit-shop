/// <reference types="react-scripts" />

interface Window {
    web3: any;
    ethereum:any
}