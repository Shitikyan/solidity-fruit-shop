export const HeaderRow = () => {
    return (
        <tr>
            <th>NFT</th>
            <th>Fruit</th>
            <th>PRICE</th>
            <th>Amount</th>
            <th>QTY</th>
            <th>Total</th>
        </tr>
    );
}
